#!/bin/bash

# Record the start time
START_TIME=$(date +%s)

# Simulate a task (replace this with actual job logic)
sleep 5

# Record the end time
END_TIME=$(date +%s)

# Calculate the duration of the job
DURATION=$((END_TIME - START_TIME))

# Push the job duration to Prometheus Pushgateway
cat <<EOF | curl --data-binary @- http://prometheus-prometheus-pushgateway:9091/metrics/job/k8s_cronjob
# TYPE job_duration_seconds gauge
job_duration_seconds $DURATION
EOF
